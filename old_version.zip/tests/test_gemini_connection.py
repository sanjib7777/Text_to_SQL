from llm.gemini_connection import GeminiLLM


def test_resolve_model_falls_back_for_outdated_name():
    assert GeminiLLM._resolve_model("gemini-2.0-flash") == "gemini-2.5-flash"


def test_resolve_model_keeps_supported_name():
    assert GeminiLLM._resolve_model("gemini-2.5-flash") == "gemini-2.5-flash"
