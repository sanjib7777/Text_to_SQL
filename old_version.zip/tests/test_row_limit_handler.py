from services.row_limit_handler import RowLimitHandler


def test_latest_sales_orders_applies_row_limit_wrapper():
    handler = RowLimitHandler()

    generated_sql = (
        "SELECT o.UNIT_PRICE, o.CALC_TOTAL_PRICE "
        "FROM SA_SALES_ORDER o "
        "WHERE TRUNC(o.ORDER_DATE) >= TO_DATE('2026-07-13', 'YYYY-MM-DD') "
        "AND TRUNC(o.ORDER_DATE) < TO_DATE('2026-08-13', 'YYYY-MM-DD') "
        "AND DELETED_FLAG = 'N' "
        "AND o.COMPANY_CODE = '01' "
        "AND o.BRANCH_CODE = '01.01' "
        "ORDER BY o.ORDER_DATE DESC"
    )

    modified_sql = handler.apply_limit(
        generated_sql=generated_sql,
        user_query="Show the latest 15 sales orders",
    )

    assert modified_sql.startswith("SELECT *\nFROM (")
    assert "WHERE ROWNUM <= 15" in modified_sql


def test_pagination_applies_oracle_rownum_window():
    handler = RowLimitHandler()

    modified_sql = handler.apply_pagination(
        generated_sql="SELECT ORDER_NO FROM SA_SALES_ORDER ORDER BY ORDER_NO",
        page=2,
        page_size=100,
    )

    assert "WHERE ROWNUM <= 200" in modified_sql
    assert "WHERE row_number > 100" in modified_sql
    assert "SELECT ORDER_NO FROM SA_SALES_ORDER ORDER BY ORDER_NO" in modified_sql