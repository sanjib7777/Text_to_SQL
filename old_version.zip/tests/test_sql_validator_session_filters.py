from types import SimpleNamespace

from validator.sql_validator import SQLValidator


def test_validate_session_filters_normalizes_branch_code_punctuation():
    validator = SQLValidator()

    sql = (
        "SELECT o.UNIT_PRICE, o.TOTAL_PRICE "
        "FROM SA_SALES_ORDER o "
        "WHERE TRUNC(o.ORDER_DATE) = TO_DATE('2025-07-17', 'YYYY-MM-DD') "
        "AND o.COMPANY_CODE = '01' "
        "AND o.BRANCH_CODE = '01.01' "
        "AND o.DELETED_FLAG = 'N'"
    )

    retrieved_schema = [
        {
            "table_name": "SA_SALES_ORDER",
            "columns": [
                {"name": "UNIT_PRICE"},
                {"name": "TOTAL_PRICE"},
                {"name": "ORDER_DATE"},
                {"name": "COMPANY_CODE"},
                {"name": "BRANCH_CODE"},
                {"name": "DELETED_FLAG"},
            ],
        }
    ]

    session = SimpleNamespace(company_code="01", branch_code="01.01`")

    valid, message = validator.validate(
        sql=sql,
        retrieved_schema=retrieved_schema,
        session=session,
    )

    assert valid is True
    assert message == "SQL is valid."