from conversational_model.conversation_memory import ConversationMemory


def test_add_message_stores_role_and_content_as_plain_dict():
    memory = ConversationMemory(max_messages=3)

    memory.add_message("session-1", "user", "hello")

    history = memory.get_history("session-1")

    assert len(history) == 1
    assert history[0]["role"] == "user"
    assert history[0]["content"] == "hello"
