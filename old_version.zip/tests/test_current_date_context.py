from services.current_date_context import CurrentDateContext


def test_gregorian_month_year_uses_ad_range():
    context = CurrentDateContext()

    _, date_range = context.get_context(
        "Show sales orders for the month of August 2025"
    )

    assert date_range["ad_start"].strftime("%Y-%m-%d") == "2025-08-01"
    assert date_range["ad_next"].strftime("%Y-%m-%d") == "2025-09-01"


def test_future_month_year_defaults_to_bs_when_year_exceeds_current_ad_year():
    context = CurrentDateContext()

    _, date_range = context.get_context(
        "Show sales orders for the month of August 2082"
    )

    assert date_range["bs_start"].year == 2082
    assert date_range["bs_start"].month == 8
    assert date_range["bs_next"].month == 9


def test_bare_gregorian_year_uses_ad_range():
    context = CurrentDateContext()

    _, date_range = context.get_context("Return sales orders placed in 2025")

    assert date_range["ad_start"].strftime("%Y-%m-%d") == "2025-01-01"
    assert date_range["ad_next"].strftime("%Y-%m-%d") == "2026-01-01"


def test_explicit_ad_date_uses_single_day_range():
    context = CurrentDateContext()

    _, date_range = context.get_context(
        "Show the unit price and total price for order date 2025-07-17"
    )

    assert date_range["ad_start"].strftime("%Y-%m-%d") == "2025-07-17"
    assert date_range["ad_next"].strftime("%Y-%m-%d") == "2025-07-18"