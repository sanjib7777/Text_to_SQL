from api.session_context import SessionContext
from prompts.prompt_builder import PromptBuilder
from services.sql_generation_pipeline import SQLGenerationPipeline
from validator.sql_validator import SQLValidator


def test_extract_invalid_column_parses_error_message():
    pipeline = SQLGenerationPipeline.__new__(SQLGenerationPipeline)

    assert pipeline.extract_invalid_column(
        "Column 'ORDER_ID' does not exist"
    ) == "ORDER_ID"


def test_extract_invalid_column_returns_none_when_not_found():
    pipeline = SQLGenerationPipeline.__new__(SQLGenerationPipeline)

    assert pipeline.extract_invalid_column("SQL syntax error") is None


def test_prompt_builder_includes_current_session_context():
    builder = PromptBuilder()
    session = SessionContext(
        company_code="01",
        branch_code="KTM01",
    )

    messages = builder.build_messages(
        user_question="Show sales",
        session=session,
        retrieved_schema=[],
        retrieved_examples=[],
        current_date_context="",
    )

    prompt_text = messages[1]["content"]

    assert "FILTERS TO USE IN EVERY SQL QUERY" in prompt_text
    assert "Company Code:" in prompt_text
    assert "01" in prompt_text
    assert "Branch Code:" in prompt_text
    assert "KTM01" in prompt_text
    assert "COMPANY_CODE = {company_code}" in prompt_text


def test_validator_allows_allowlisted_tables_not_in_retrieved_schema():
    validator = SQLValidator()
    session = SessionContext(company_code="01", branch_code="01.01")
    sql = (
        "SELECT * FROM ("
        "SELECT s.ITEM_CODE FROM SA_SALES_ORDER s "
        "JOIN IP_ITEM_MASTER_SETUP im ON s.ITEM_CODE = im.ITEM_CODE "
        "WHERE s.COMPANY_CODE = '01' AND s.BRANCH_CODE = '01.01'"
        ") WHERE ROWNUM <= 100"
    )
    retrieved_schema = [
        {
            "table_name": "SA_SALES_ORDER",
            "columns": [{"name": "ITEM_CODE"}, {"name": "COMPANY_CODE"}, {"name": "BRANCH_CODE"}],
        }
    ]

    valid, message = validator.validate(
        sql=sql,
        retrieved_schema=retrieved_schema,
        session=session,
    )

    assert valid is True
    assert message == "SQL is valid."


def test_validator_accepts_valid_oracle_rownum_wrapper():
    validator = SQLValidator()
    session = SessionContext(company_code="01", branch_code="01.01")
    sql = (
        "SELECT * FROM ("
        "SELECT o.CUSTOMER_CODE, im.ITEM_EDESC, o.UNIT_PRICE, o.CALC_TOTAL_PRICE "
        "FROM SA_SALES_ORDER o "
        "JOIN IP_ITEM_MASTER_SETUP im ON o.ITEM_CODE = im.ITEM_CODE AND o.COMPANY_CODE = im.COMPANY_CODE "
        "WHERE o.COMPANY_CODE = '01' AND o.BRANCH_CODE = '01.01' AND o.DELETED_FLAG = 'N' "
        "AND TRUNC(o.ORDER_DATE) >= TO_DATE('2025-07-17', 'YYYY-MM-DD') "
        "AND TRUNC(o.ORDER_DATE) < TO_DATE('2026-07-17', 'YYYY-MM-DD') "
        "ORDER BY o.ORDER_DATE"
        ") WHERE ROWNUM <= 100"
    )
    retrieved_schema = [
        {
            "table_name": "SA_SALES_ORDER",
            "columns": [
                {"name": "CUSTOMER_CODE"},
                {"name": "ITEM_CODE"},
                {"name": "COMPANY_CODE"},
                {"name": "BRANCH_CODE"},
                {"name": "DELETED_FLAG"},
                {"name": "ORDER_DATE"},
                {"name": "UNIT_PRICE"},
                {"name": "CALC_TOTAL_PRICE"},
            ],
        },
        {
            "table_name": "IP_ITEM_MASTER_SETUP",
            "columns": [
                {"name": "ITEM_CODE"},
                {"name": "COMPANY_CODE"},
                {"name": "ITEM_EDESC"},
            ],
        },
    ]

    valid, message = validator.validate(
        sql=sql,
        retrieved_schema=retrieved_schema,
        session=session,
    )

    assert valid is True
    assert message == "SQL is valid."


def test_validator_rejects_invalid_qualified_column_with_local_schema_fallback():
    validator = SQLValidator()
    sql = (
        "SELECT * FROM ("
        "SELECT o.ORDER_NO, c.PARTY_NAME, im.ITEM_EDESC, o.CALC_TOTAL_PRICE AS TOTAL_PRICE "
        "FROM SA_SALES_ORDER o "
        "JOIN SA_CUSTOMER_SETUP c ON o.CUSTOMER_CODE = c.CUSTOMER_CODE AND o.COMPANY_CODE = c.COMPANY_CODE "
        "JOIN IP_ITEM_MASTER_SETUP im ON o.ITEM_CODE = im.ITEM_CODE AND o.COMPANY_CODE = im.COMPANY_CODE "
        "WHERE o.COMPANY_CODE = '01' AND o.BRANCH_CODE = '01.01' AND o.DELETED_FLAG = 'N' "
        ") WHERE ROWNUM <= 11"
    )
    retrieved_schema = [
        {
            "table_name": "SA_SALES_ORDER",
            "columns": [
                {"name": "ORDER_NO"},
                {"name": "CALC_TOTAL_PRICE"},
                {"name": "CUSTOMER_CODE"},
                {"name": "COMPANY_CODE"},
                {"name": "BRANCH_CODE"},
                {"name": "ORDER_DATE"},
                {"name": "DELETED_FLAG"},
            ],
        },
        {
            "table_name": "IP_ITEM_MASTER_SETUP",
            "columns": [
                {"name": "ITEM_CODE"},
                {"name": "COMPANY_CODE"},
                {"name": "ITEM_EDESC"},
            ],
        },
    ]

    valid, message = validator.validate(
        sql=sql,
        retrieved_schema=retrieved_schema,
    )

    assert valid is False
    assert "PARTY_NAME" in message
    assert "SA_CUSTOMER_SETUP" in message
