import json
import os
from collections import Counter

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
FILE_PATH = "database_schema_fk_pk.json"  


def find_duplicate_tables(file_path: str):
    if not os.path.exists(file_path):
        print(f" Error: File '{file_path}' not found.")
        return

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, list):
            print(" Error: Expected top-level JSON structure to be a list of table objects.")
            return

        # Extract all table names from the JSON objects
        table_names = [
            item.get("table_name")
            for item in data
            if isinstance(item, dict) and item.get("table_name")
        ]

        # Count occurrences of each table name
        counts = Counter(table_names)

        # Filter out table names that appear more than once
        duplicates = {name: count for name, count in counts.items() if count > 1}

        # Output Results
        print(f" Summary:")
        print(f"   Total records in file: {len(data)}")
        print(f"   Unique table names:   {len(counts)}")
        print("--------------------------------------------------")

        if duplicates:
            print(f" Found {len(duplicates)} duplicate table(s):\n")
            for table_name, count in duplicates.items():
                print(f"   Table: '{table_name}' | Count: {count} times")
        else:
            print(" No duplicate tables found! All table records are unique.")

    except json.JSONDecodeError as e:
        print(f" JSON Parsing Error: The file contains invalid JSON formatting. Details: {e}")
    except Exception as e:
        print(f" Unexpected error: {e}")


if __name__ == "__main__":
    find_duplicate_tables(FILE_PATH)