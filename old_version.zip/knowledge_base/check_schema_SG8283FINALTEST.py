import json
import os

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
INPUT_FILE = "database_schema_fk_pk.json"
TARGET_SCHEMA = "SG8283FINALTEST"
TXT_OUTPUT_FILE = f"{TARGET_SCHEMA}_tables.txt"


def get_and_save_schema_tables(input_file: str, target_schema: str, output_txt: str):
    if not os.path.exists(input_file):
        print(f" Error: File '{input_file}' not found.")
        return

    try:
        with open(input_file, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict) or "schemas" not in data:
            print(" Error: Expected top-level JSON structure with a 'schemas' key.")
            return

        target_schema_found = False
        tables_list = []

        # Search for the specific schema
        for schema_obj in data.get("schemas", []):
            schema_name = schema_obj.get("schema", "")
            
            # Case-insensitive schema matching
            if schema_name.strip().upper() == target_schema.strip().upper():
                target_schema_found = True
                schema_tables = schema_obj.get("tables", [])
                
                for t in schema_tables:
                    t_name = t.get("table_name")
                    if t_name:
                        tables_list.append(t_name)
                break

        if not target_schema_found:
            print(f" Schema '{target_schema}' was not found in '{input_file}'.")
            return

        # Prepare text content (comma-separated tables)
        text_content = (
            f"Schema Name: {target_schema}\n"
            + "=" * 50 + "\n"
            + f"Total Tables Count: {len(tables_list)}\n"
            + "=" * 50 + "\n"
            + "Tables List:\n"
            + "- " * 25 + "\n"
            + ", ".join(tables_list)  # <-- comma-separated list
        )

        # 1. Print to console
        print(text_content)

        # 2. Save to text file
        with open(output_txt, "w", encoding="utf-8") as txt_file:
            txt_file.write(text_content)

        print("\n" + "=" * 50)
        print(f" Successfully saved table list to file: '{output_txt}'")

    except json.JSONDecodeError as e:
        print(f" JSON Parsing Error: {e}")
    except Exception as e:
        print(f" Unexpected error: {e}")


if __name__ == "__main__":
    get_and_save_schema_tables(INPUT_FILE, TARGET_SCHEMA, TXT_OUTPUT_FILE)
