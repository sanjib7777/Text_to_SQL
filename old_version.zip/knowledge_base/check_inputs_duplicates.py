import json
import os
from collections import Counter, defaultdict

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
FILE_PATH = "database_schema_fk_pk.json"


def find_duplicate_input_tables(file_path: str):
    if not os.path.exists(file_path):
        print(f"❌ Error: File '{file_path}' not found.")
        return

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        if not isinstance(data, dict) or "schemas" not in data:
            print("❌ Error: Expected top-level JSON structure with a 'schemas' key.")
            return

        table_names = []
        table_to_schemas = defaultdict(list)

        # Iterate through all schemas and nested tables
        for schema_obj in data.get("schemas", []):
            schema_name = schema_obj.get("schema", "UNKNOWN_SCHEMA")
            
            for table in schema_obj.get("tables", []):
                t_name = table.get("table_name")
                if t_name:
                    table_names.append(t_name)
                    table_to_schemas[t_name].append(schema_name)

        # Count occurrences of each table name
        counts = Counter(table_names)

        # Filter out duplicates
        duplicates = {name: count for name, count in counts.items() if count > 1}

        # Output Results
        print("📊 Input Schema Duplicate Analysis")
        print("--------------------------------------------------")
        print(f"   • Database:            {data.get('database', 'N/A')}")
        print(f"   • Total schemas:       {len(data.get('schemas', []))}")
        print(f"   • Total tables found:  {len(table_names)}")
        print(f"   • Unique table names:  {len(counts)}")
        print("--------------------------------------------------")

        if duplicates:
            print(f"⚠️ Found {len(duplicates)} duplicate table(s):\n")
            for table_name, count in duplicates.items():
                schemas_str = ", ".join(table_to_schemas[table_name])
                print(f"   • Table: '{table_name}'")
                print(f"     └─ Count: {count} times (Found in schemas: {schemas_str})")
        else:
            print("✅ No duplicate tables found across all schemas!")

    except json.JSONDecodeError as e:
        print(f"❌ JSON Parsing Error: Invalid syntax inside file. Details: {e}")
    except Exception as e:
        print(f"❌ Unexpected error: {e}")


if __name__ == "__main__":
    find_duplicate_input_tables(FILE_PATH)