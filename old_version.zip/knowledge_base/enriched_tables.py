import json
import os
import time
from openai import OpenAI

# ---------------------------------------------------------------------------
# Configuration & Local Ollama Client Setup
# ---------------------------------------------------------------------------
INPUT_FILE = "database_schema_fk_pk.json"
OUTPUT_FILE = "enriched_tables_schema.json"
MODEL_ID = "qwen2.5:7b"

# Connect to local Ollama server endpoint (No API key needed)
client = OpenAI(
    base_url="http://localhost:11434/v1",
    api_key="ollama",  
)

# ---------------------------------------------------------------------------
# JSON Schema for Structured Output Validation
# ---------------------------------------------------------------------------
table_json_schema = {
    "type": "object",
    "properties": {
        "table_name": {"type": "string"},
        "purpose": {"type": "string"},
        "used_for": {
            "type": "array",
            "items": {"type": "string"}
        },
        "primary_key": {

            "type": "array",
            "items": {"type": "string"}
        },
        "foreign_keys": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "column": {"type": "string"},
                    "references": {"type": "string"}
                },
                "required": ["column", "references"]
            }
        },
        "columns": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "name": {"type": "string"},
                    "type": {"type": "string"},
                    "description": {"type": "string"}
                },
                "required": ["name", "type", "description"]
            }
        },
        "sample_queries": {
            "type": "array",
            "items": {"type": "string"}
        }
    },
    "required": [
        "table_name",
        "purpose",
        "used_for",
        "primary_key",
        "foreign_keys",
        "columns",
        "sample_queries"
    ]
}

SYSTEM_INSTRUCTION = """
You are an expert Database Administrator and Data Architect.
Analyze the raw database schema and return structured JSON metadata.

For each table provided, generate:
- 'purpose': 1-sentence summary of what this table manages.
- 'used_for': 3-5 core functional areas relying on this data.
- 'columns': List of columns with a clear, 1-sentence business description for each.
- 'sample_queries': 3-4 natural language business queries for this table.

--- EXAMPLE OUTPUT FORMAT ---
{
  "table_name": "HRIS_EMPLOYEE",
  "purpose": "Stores employee master information.",
  "used_for": ["Employee details", "Attendance", "Payroll", "Leave Management"],
  "primary_key": ["EMP_ID"],
  "foreign_keys": ["BRANCH_CODE"],
  "columns": [
    {"name": "EMP_ID", "type": "NUMBER", "description": "Unique employee identifier"},
    {"name": "EMP_NAME", "type": "VARCHAR2", "description": "Employee full name"}
  ],
  "sample_queries": ["List employees", "Show employee salary", "Employees by department"]
}
"""

# ---------------------------------------------------------------------------
# Persistence Helpers
# ---------------------------------------------------------------------------
def load_existing_results() -> list:
    """Safely loads existing results even if the file was corrupted during an abrupt exit."""
    if not os.path.exists(OUTPUT_FILE):
        return []
    
    try:
        with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if isinstance(data, list):
                return data
    except Exception:
        # If the JSON file was broken mid-write on exit, attempt auto-recovery
        print("Unfinished JSON structure detected from abrupt exit. Cleaning up file for auto-recovery...")
        with open(OUTPUT_FILE, "r", encoding="utf-8") as f:
            raw = f.read().strip()
        
        # Remove trailing commas/dangling syntax and close the JSON array safely
        if raw.startswith("["):
            last_valid_bracket = raw.rfind("}")
            if last_valid_bracket != -1:
                cleaned_json = raw[:last_valid_bracket + 1] + "\n]"
                try:
                    recovered_data = json.loads(cleaned_json)
                    print(f" Recovered {len(recovered_data)} valid tables from saved file.")
                    return recovered_data
                except Exception:
                    pass
    return []

def save_single_table(table_result: dict, existing_records: list):
    existing_records.append(table_result)
    with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
        json.dump(existing_records, f, indent=2, ensure_ascii=False)

# ---------------------------------------------------------------------------
# Local Processing Function
# ---------------------------------------------------------------------------
def enrich_table_with_ollama(table_data: dict, max_retries: int = 3) -> dict:
    prompt_content = f"""
    Analyze this Oracle table schema and generate structured metadata:

    Table Name: {table_data.get('table_name')}
    Primary Keys: {json.dumps(table_data.get('primary_keys', []))}
    Foreign Keys: {json.dumps(table_data.get('foreign_keys', []))}
    Columns: {json.dumps(table_data.get('columns', []))}
    """

    messages = [
        {"role": "system", "content": SYSTEM_INSTRUCTION},
        {"role": "user", "content": prompt_content}
    ]

    for attempt in range(1, max_retries + 1):
        try:
            completion = client.chat.completions.create(
                model=MODEL_ID,
                messages=messages,
                temperature=0.2,  # Lower temperature helps local LLMs adhere to JSON schema
                response_format={
                    "type": "json_object", 
                    "json_schema": {
                        "name": "table_metadata",
                        "strict": True,
                        "schema": table_json_schema}
                }
            )

            response_content = completion.choices[0].message.content
            return json.loads(response_content)

        except Exception as e:
            if attempt < max_retries:
                wait_time = attempt * 2
                print(f" [Attempt {attempt}/{max_retries}] Parsing/Local error: {e}. Retrying in {wait_time}s...")
                time.sleep(wait_time)
            else:
                raise e

# ---------------------------------------------------------------------------
# Main Execution Loop
# ---------------------------------------------------------------------------
def main():
    if not os.path.exists(INPUT_FILE):
        print(f"Error: Could not find input file '{INPUT_FILE}'.")
        return

    with open(INPUT_FILE, "r", encoding="utf-8") as f:
        db_data = json.load(f)

    # 1. Load already saved records
    enriched_tables = load_existing_results()
    
    # Extract unique set of table names already completed
    processed_table_names = {
        t.get("table_name") for t in enriched_tables 
        if isinstance(t, dict) and t.get("table_name")
    }

    print(f" Total completed tables found in file: {len(processed_table_names)}")

    # 2. Iterate through schema and process ONLY missing tables
    for schema_obj in db_data.get("schemas", []):
        for table in schema_obj.get("tables", []):
            table_name = table.get("table_name")

            # Fast skip: If the table name is already in our saved JSON, do nothing
            if table_name in processed_table_names:
                print(f" Skipping '{table_name}' (already in enriched_tables_schema.json)")
                continue

            print(f" Processing missing table: {table_name}...")

            try:
                enriched_data = enrich_table_with_ollama(table)
                save_single_table(enriched_data, enriched_tables)
                
                # Instantly mark as processed so it won't repeat in the same run
                processed_table_names.add(table_name)
                print(f" Successfully saved '{table_name}' to '{OUTPUT_FILE}'.")

            except Exception as e:
                print(f" Failed to process '{table_name}': {e}")

    print(f"\n All done! Total {len(enriched_tables)} tables saved in '{OUTPUT_FILE}'.")

if __name__ == "__main__":
    main()