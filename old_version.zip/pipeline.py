from vector_db.embeddings import EmbeddingModel
from retriever.schema_retriever import SchemaRetriever
# from retriever.column_retriever import ColumnRetriever
from retriever.sql_example_retriever import SQLExampleRetriever

from prompts.prompt_builder import PromptBuilder

from llm.ollama_client import OllamaClient

from validator.sql_validator import SQLValidator

from validator.sql_executor import SQLExecutor
from services.current_date_context import CurrentDateContext
from cache.cache_manager import CacheManager
from cache.semantic_cache import SemanticCache

from prompts.sql_correction_prompt import SQLCorrectionPrompt


class SQLGenerationPipeline:

    def __init__(self):
        self.embedding_model = EmbeddingModel()

        self.schema_retriever = SchemaRetriever()

        # self.column_retriever = ColumnRetriever()

        self.example_retriever = SQLExampleRetriever()

        self.semantic_cache = SemanticCache()

        self.prompt_builder = PromptBuilder()

        self.llm = OllamaClient()

        self.validator = SQLValidator()

        self.executor = SQLExecutor()

        self.date_context = CurrentDateContext()

        self.cache_manager = CacheManager()

        self.MAX_SQL_RETRIES = 3

    ##############################################################

    def clean_sql(self, sql):

        if not sql:
            return ""

        sql = sql.strip()

      
        if sql.startswith("```sql"):
            sql = sql[len("```sql"):]

        elif sql.startswith("```"):
            sql = sql[len("```"):]

        if sql.endswith("```"):
            sql = sql[:-3]

        sql = sql.strip()

        # Remove trailing semicolon
        if sql.endswith(";"):
            sql = sql[:-1].strip()

        return sql

    def run(self, user_query):

        ##########################################################
        # STEP 0 : CHECK REDIS CACHE
        ##########################################################

        print("=" * 80)
        print("STEP 0 : Checking Redis Cache")
        print("=" * 80)

        try:

            cached_result = self.cache_manager.get_cache_by_query(
                user_query
            )

            if cached_result:

                print("CACHE HIT")
                print("Returning result from Redis.")

                return {
                    "success": True,
                    "cache_hit": True,

                    "generated_sql": cached_result["sql"],

                    "columns": cached_result["columns"],

                    "rows": cached_result["rows"],

                    "row_count": cached_result["row_count"],

                    # "cache_key": cached_result["cache_key"]
                }

            print("CACHE MISS")

        except Exception as e:

            # Redis failure should not stop the application
            print(f"Redis cache check failed: {e}")


        # searching for semantic cache

        query_vector = self.embedding_model.embed(user_query)

        print("query vector", query_vector)

        cache_result = self.semantic_cache.search(
            query_vector=query_vector
        )

        if cache_result:

            print("\nSemantic Cache HIT")

            cache_key = cache_result["cache_key"]

            # Now retrieve actual SQL + data from Redis
            cached_data = self.cache_manager.get_cache(cache_key)

            if cached_data:

                return {
                    "success": True,
                    "cache_hit": True,
                    # "similarity_score": cache_result["similarity_score"],
                    "generated_sql": cached_data["sql"],
                    "columns": cached_data["columns"],
                    "rows": cached_data["rows"],
                    "row_count": cached_data["row_count"]
                }

            print("Qdrant matched but Redis data was not found.")

        else:

            print("\nSemantic Cache MISS")

        print("=" * 80)
        print("STEP 1 : Retrieving Schema")
        print("=" * 80)

        retrieved_schema = self.schema_retriever.retrieve(
            query_vector=query_vector,
            top_k=3
        )

        print(f"Retrieved {len(retrieved_schema)} tables")

        ##########################################################

        # print("\n" + "=" * 80)
        # print("STEP 2 : Retrieving Columns")
        # print("=" * 80)

        # retrieved_columns = self.column_retriever.retrieve(
        #     query_vector=query_vector,
        #     top_k=20
        # )

        # print(f"Retrieved {len(retrieved_columns)} columns")

        # ##########################################################

        print("\n" + "=" * 80)
        print("STEP 3 : Retrieving SQL Examples")
        print("=" * 80)

        retrieved_examples = self.example_retriever.retrieve(
            query_vector=query_vector,
            top_k=5
        )

        print(f"Retrieved {len(retrieved_examples)} examples")

        ##########################################################

        print("\n" + "=" * 80)
        print("STEP 4 : Building Prompt")
        print("=" * 80)

        date_context = self.date_context.get_context()

        messages = self.prompt_builder.build_messages(
            user_question=user_query,
            retrieved_schema=retrieved_schema,
            # retrieved_columns=retrieved_columns,
            retrieved_examples=retrieved_examples,
            current_date_context=date_context,

        )

        system_prompt =  messages[0]["content"]
        print(messages[0]["content"])

        print("=" * 100)
        user_prompt = messages[1]["content"] 
        print(messages[1]["content"]) 

        ##########################################################

        print("\n" + "=" * 80)
        print("STEP 5 : Generating SQL")
        print("=" * 80)

        generated_sql = self.llm.chat_with_model(user_prompt, system_prompt)

        

        generated_sql = self.clean_sql(generated_sql)

        print("\n Initial Generated SQL\n")
        print(generated_sql)

        ##########################################################

        print("\n" + "=" * 80)
        print("STEP 6 : Validating SQL")
        print("=" * 80)

        sql_valid = False
        validation_message = ""

        for attempt in range(self.MAX_SQL_RETRIES + 1):

            print(
                f"\nSQL Validation Attempt "
                f"{attempt + 1}/{self.MAX_SQL_RETRIES + 1}"
            )

            is_valid, message = self.validator.validate(
                sql=generated_sql,
                retrieved_schema=retrieved_schema,
            )

            if is_valid:

                print("SQL Validation Successful")

                sql_valid = True
                break

            print("SQL Validation Failed")
            print(message)

            validation_message = message

            # ------------------------------------------------------
            # Don't retry after final attempt
            # ------------------------------------------------------

            if attempt >= self.MAX_SQL_RETRIES:

                break

            print("\nSending validation error back to LLM...")

            correction_prompt = SQLCorrectionPrompt.build(
                user_question=user_query,
                generated_sql=generated_sql,
                validation_error=validation_message,
                retrieved_schema=retrieved_schema,
            )

            generated_sql = self.llm.chat_with_model(
                correction_prompt,
                system_prompt
            )

            generated_sql = self.clean_sql(generated_sql)

            print("\nCorrected SQL:\n")
            print(generated_sql)

            
        if not sql_valid:

            return {
                "success": False,
                "stage": "validator",
                "error": validation_message,
                "generated_sql": generated_sql,
            }
        ##########################################################

        print("\n" + "=" * 80)
        print("STEP 7 : Executing SQL")
        print("=" * 80)

        result = self.executor.execute(generated_sql)

        if not result["success"]:

            print(result["error"])

            return {
                "success": False,
                "stage": "oracle",
                "error": result["error"],
                "generated_sql": generated_sql,
            }

        ##########################################################
        # STEP 7 : STORE SUCCESSFUL RESULT IN REDIS
        ##########################################################
        print("\n" + "=" * 80)
        print("STEP 7 : Storing Result in Redis")
        print("=" * 80)

        try:

            cache_key = self.cache_manager.save_cache(

                query=user_query,

                sql=generated_sql,

                columns=result["columns"],

                rows=result["rows"],

                execution_time=None
            )

            print("Successfully stored in Redis")

            print(f"Cache Key : {cache_key}")

        except Exception as e:

            print(f"Redis cache storage failed: {e}")

            cache_key = None

        self.semantic_cache.store(
            query=user_query,
            query_vector=query_vector,
            cache_key=cache_key
        )

        return {
            "success": True,
            "generated_sql": generated_sql,
            "columns": result["columns"],
            "rows": result["rows"],
            "row_count": result["row_count"],
        }


# if __name__ == "__main__":

#     pipeline = SQLGenerationPipeline()

#     while True:

#         print()

#         question = input("Ask Question : ")

#         if question.lower() == "exit":
#             break

#         result = pipeline.run(question)

#         print("\n" + "=" * 80)
#         print("FINAL RESULT")
#         print("=" * 80)

#         if result["success"]:

#             print("\nGenerated SQL:\n")
#             print(result["generated_sql"])

#             print("\nColumns:")
#             print(result["columns"])

#             print(f"\nRows Returned : {result['row_count']}")

#             for row in result["rows"][:10]:
#                 print(row)

#         else:

#             print("\nError Stage :", result["stage"])
#             print(result["error"])